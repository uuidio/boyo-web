export default {
  /**
   * @description token在Cookie中存储的天数，默认7天
   */
  cookieExpires: 90,

  // 默认页面查询数量
  default_page_count: 20,
  // 默认页面查询总数量
  default_page_total: 20,
};
