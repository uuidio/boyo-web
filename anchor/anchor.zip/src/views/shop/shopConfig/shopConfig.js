import Swipers from '@C/custom/temps/WapSwiper';
import Navs from '@C/custom/temps/WapNavs';
import editSwipers from '@C/custom/editTemps/editSwiper';
import editNavs from '@C/custom/editTemps/editNavs';

export {
  Swipers, Navs, editSwipers, editNavs,
};
