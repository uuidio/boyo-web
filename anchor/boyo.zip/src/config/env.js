export default {
  // baseURL: 'https://lanlink.smartconns.com/seller/', // 极汇GO测试
  baseURL: 'https://lanlink.smartconns.com/live/', // 极汇GO测试
  // baseURL: 'https://ego.ytholidayplaza.com/seller/',//极汇GO正式

  // ##极汇GO集团正式 切记要区分清楚，避免影响到原本EGO
  // baseURL: 'http://ytxspt.ytholidayplaza.com/seller/',
};
