<template>
  <div class="content">
    <div class="mb20">
      <div class="list-nav">
        <div>
          <a-button type="primary" @click="aModel=true"> + 新建笔记</a-button>
          <a-button type="danger" @click="$router.push('/show_text/list')" icon="rollback"> 返回</a-button>
        </div>
      </div>
    </div>
    <div>
      <a-table :pagination="false" :columns="columns" :data-source="dataList">
        <span slot="tags" slot-scope="tags">
          <a-tag v-for="tag in tags" :key="tag" :color="'geekblue'">{{ tag.toUpperCase() }}</a-tag>
        </span>
        <span slot="action">
          <a-button type="primary" size="small" icon="edit" @click="aModel=true">编辑</a-button>
        </span>
      </a-table>
      <div class="pageBox" v-if="listsData.length !== 0">
        <a-pagination
          :total="pages.total"
          :showTotal="total => `共 ${total} 条数据`"
          :pageSize="pages.per_page"
          v-model="currentPages"
          @change="pageChange"
        />
      </div>
    </div>
    <a-modal title="新建笔记" v-model="aModel" @ok="onSubmit()">
      <a-form-model ref="ruleForm" :model="form_params" :rules="rules">
        <a-form-model-item label="笔记标题:" :label-col="{ md: 6, xs: 24 }" :wrapper-col="{ md: 18, xs: 24 }" prop="p1">
          <a-input style="width: 100%" v-model="form_params.p1" placeholder="请输入笔记标题"/>
        </a-form-model-item>
        <a-form-model-item label="笔记关键词1:" :label-col="{ md: 6, xs: 24 }" :wrapper-col="{ md: 18, xs: 24 }">
          <a-input style="width: 100%" v-model="form_params.p2" placeholder="笔记关键词1" maxLength="6"/>
        </a-form-model-item>
        <a-form-model-item label="笔记关键词2:" :label-col="{ md: 6, xs: 24 }" :wrapper-col="{ md: 18, xs: 24 }">
          <a-input style="width: 100%" v-model="form_params.p3" placeholder="笔记关键词2"/>
        </a-form-model-item>
        <a-form-model-item label="笔记关键词3:" :label-col="{ md: 6, xs: 24 }" :wrapper-col="{ md: 18, xs: 24 }">
          <a-input style="width: 100%" v-model="form_params.p4" placeholder="笔记关键词3"/>
        </a-form-model-item>
        <a-form-model-item label="内容:" :label-col="{ md: 6, xs: 24 }" :wrapper-col="{ md: 18, xs: 24 }">
          <a-input type="textarea" style="width: 100%" v-model="form_params.p5" placeholder="请输入文案内容"/>
        </a-form-model-item>
        <a-form-model-item label="排序:" :label-col="{ md: 6, xs: 24 }" :wrapper-col="{ md: 18, xs: 24 }" prop="p6">
          <a-input style="width: 100%" v-model="form_params.p6" placeholder="请输入已存在序号，并调换"/>
        </a-form-model-item>
      </a-form-model>
    </a-modal>
  </div>
</template>

<script>
import { mapState, mapActions } from 'vuex';

export default {
  computed: {
    ...mapState({
      listsData: state => state.trade.selfExtractData,
      pages: state => state.trade.selfExtractPages,
      listField: state => state.trade.selfExtractFields,
      exportData: state => state.trade.exportData,
    }),
  },
  data() {
    return {
      dataList: [
          { p1:'这是名称',p2:['嘻嘻','哈哈','呵呵'],p3:'1' },
          { p1:'这是名称3',p2:['嘻嘻','哈哈','呵呵'],p3:'2' },
          { p1:'这是名称6',p2:['嘻嘻','哈哈','呵呵'],p3:'3' }
      ],
      columns: [
        {
          title: '笔记本名称',
          dataIndex: 'p1',
          key: 'p1',

        },
        {
          title: '关键字',
          dataIndex: 'p2',
          key: 'p2',
          scopedSlots: { customRender: 'tags' },
        },
        {
          title: '序号',
          dataIndex: 'p3',
          key: 'p3',
        },
        {
          title: '操作',
          key: 'action',
          dataIndex: 'action',
          scopedSlots: { customRender: 'action' },
        }],
      getData: {
        page: 1,
      },
      exportForm: {
        page: 1,
      },
      currentParam: {},
      filterParams: {},
      exportModel: false,
      isFillter: false,
      currentAct: '-1',
      currentPages: 1,
      title: '售后列表筛选',
      timeVisible: true,
      // 新的代码----------------------------------------------------------------------------------
      form_params: {
        p1: '', // 名称
        p2: '', // 类型
        p3: '', // 类型
        p4: '', // 类型
        p5: '', // 类型
        p6: '', // 类型
      },
      rules: {
        p1: [
          { required: true, message: '请输入笔记标题', trigger: 'blur' },
        ],
        p6: [
          { required: true, message: '请输入排序', trigger: 'blur' },
          { pattern: /^[1-9]\d*$/, message: '请输入大于0正整数' },
        ],
      },
      aModel: false, // 弹框
    };
  },
  methods: {
    ...mapActions({
      fetchLists: 'trade/selfExtractList',
      exportFilter: 'trade/exportselfExtract',
    }),
      open_aModel(type, row) {
          if (type === 'add') {
              this.form_params.p1 = ''
              this.form_params.p1 = ''
          } else {
              this.form_params.p1 = row.p1
              this.form_params.p2 = row.p2
          }
      },
    onSubmit() {
      this.$refs.ruleForm.validate(valid => {
        if (valid) {
          alert('submit!');
        } else {
          console.log('error submit!!');
          return false;
        }
      });
    },
    pageChange(page) {
      const params = this.isFillter ? this.filterParams : this.currentParam;
      //   params.status = params.status >= 0 ? params.status : "";
      params.page = page;
      this.fetchLists(params);
    },
    formatJson(filterVal, jsonData) {
      return jsonData.map(v => filterVal.map(j => v[j]));
    },
    goDetails(item) {
      const jumpUrl = `/trade/afterSales/detail/${item.aftersales_bn}`;
      const routeData = this.$router.resolve({ path: jumpUrl });
      window.open(routeData.href, '_blank');
      // this.$router.push({ path: jumpUrl });
    },
    orderCallback() {
      this.exportLoading = false;
      this.dataVisible = false;
      // this.orderStatusBool = false
      this.exportPathMethod(this.exportData);
      this.exportForm = {};
      this.timeItem = {};
      this.timeHide = false;
    },
  },
  mounted() {
    this.fetchLists({
      page: 1,
    });
  },
  watch: {
    exportData() {
      this.orderCallback();
    },
  },
};
</script>

<style scoped>
.list-nav {
  display: flex;
  justify-content: space-between;
}
.list-nav button {
  margin-right: 20px;
}
</style>
