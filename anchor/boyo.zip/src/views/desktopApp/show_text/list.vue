<template>
  <div class="content">
    <div class="mb20">
      <div class="list-nav">
        <div>
          <a-button type="primary" @click="open_aModel('add')"> + 新建笔记本</a-button>
        </div>
      </div>
    </div>
    <div>
      <a-table :pagination="false" rowKey="created_at" :columns="columns" :data-source="table_list">
        <span slot="action" slot-scope="text,record">
          <a-button type="primary" size="small" icon="edit" @click="open_aModel('edit',record)">编辑</a-button>
          <a-button type="danger" size="small" icon="search"  style="margin-left: 10px;" @click="$router.push('/show_text/list-in')">查看{{record}}</a-button>
          <a-button type="primary" size="small" icon="delete" @click="open_delete(record)" style="margin-left:10px;">删除</a-button>
        </span>
      </a-table>
      <div class="pageBox" v-if="table_list.length !== 0">
        <a-pagination
          :total="total_count"
          :showTotal="total_count => `共 ${total_count} 条数据`"
          :pageSize="20"
          v-model="table_param.page"
          @change="get_table_list"
        />
      </div>
    </div>
    <a-modal title="新建笔记本" v-model="aModel" @ok="onSubmit()">
      <a-form-model ref="ruleForm" :model="form_params" :rules="rules">
        <a-form-model-item label="笔记本名称:" :label-col="{ md: 6, xs: 24 }" :wrapper-col="{ md: 18, xs: 24 }" prop="name">
          <a-input v-model="form_params.name" placeholder="请输入笔记本名称" size="large"></a-input>
        </a-form-model-item>
        <a-form-model-item label="笔记本类型" :label-col="{ md: 6, xs: 24 }" :wrapper-col="{ md: 18, xs: 24 }" prop="type">
          <a-select v-model="form_params.type"  placeholder="请选择笔记本类型" style="width:100%" >
            <a-select-option :value="1">普通笔记本</a-select-option>
          </a-select>
        </a-form-model-item>
      </a-form-model>
    </a-modal>
  </div>
</template>

<script>
import { mapState, mapActions } from 'vuex';
import http from '@/api/http';
export default {
  computed: {

  },
  data() {
    return {
      rules: {
        name: [
          { required: true, message: '请输入笔记本名称', trigger: 'blur' },
        ],
        type: [
          { required: true, message: '请选择笔记本类型', trigger: 'change' },
        ],
      },
      columns: [
        {
          title: '标题',
          dataIndex: 'name',
          key: 'name',

        },
        {
          title: '笔记本数量',
          dataIndex: 'type',
          key: 'type',
        },
        {
          title: '序号',
          dataIndex: 'p3',
          key: 'p3',
        },
        {
          title: '操作',
          key: 'action',
          dataIndex: 'action',
          scopedSlots: { customRender: 'action' },
        }],
      aModel_title: '新建分类',
      uploadImageList: [], // 选中的图片
      form_params: {
        name: '', // 名称
      },
      aModel: false, // 弹框
      imageLists: [], // 上传
      // 列表相关的代码------------------------------------------------------------------------------
      table_param: {
        page: 1, //当前页面
        per_page: 10,
      },
      total: 0, // 总条数
      page_count: 0, // 总页数
      table_list: [], //表格数据
    };
  },
  methods: {
    ...mapActions({
      fetchLists: 'trade/selfExtractList',
    }),
    // 删除
    open_delete (row) {
      const _this = this
      this.$confirm({
        title: '是否确定删除？',
        okText: '确定',
        cancelText: '取消',
        onCancel() {},
        onOk() {
          return new Promise((resolve, reject) => {
            http.post('v1/tag/delete', { id: row.id }).then((resData) => {
              if (resData.code === 0) {
                resolve()
              } else {
                reject()
              }
            });
          }).catch(() => {
            _this.xx('异常，请联系管理员');
          });
        },
      });
    },
    // 打开弹框
    open_aModel(type, row) {
      const _this = this
      this.aModel = true
      if (type === 'add') {
        this.form_params.name = '';
        this.form_params.name = '';
        this.aModel_title = '新建分类';
      }
      if (type === 'edit') {
        this.form_params.name = row.name;
        this.aModel_title = '编辑分类';
      }
    },
    onSubmit() {
      const _this = this
      this.$refs.ruleForm.validate((valid) => {
        if (valid) {
          if(_this.aModel_title == '新建分类') {
            http.post('v1/autocue/classify/add',_this.form_params).then((resData) => {
              if (resData.code === 0) {
                _this.aModel = false
                _this.ok('添加成功')
                _this.get_table_list(1)
              }
            });
          }
          if(_this.aModel_title == '编辑分类'){

          }
        }
      });
    },
    // 获取表格列表
    get_table_list(page) {
      let _this = this;
      _this.table_param.page = page
      _this.$http.get('v1/autocue/classify/list', _this.table_param).then((resData) => {
        if (resData.code === 0) {
          _this.table_list = resData.result.lists.data
          _this.total_count = resData.result.lists.total
          _this.page_count = resData.result.lists.last_page
        }
      });
    },
  },
  created() {
    this.get_table_list(1);
  },
  mounted() {

  },
};
</script>

<style scoped>
.list-nav {
  display: flex;
  justify-content: space-between;
}
.list-nav button {
  margin-right: 20px;
}
</style>
