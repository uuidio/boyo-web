<template>
  <div class="main">
    <a-form-model ref="ruleForm" :model="form_params" :rules="rules">
      <a-form-model-item prop="p1">
        <a-input v-model="form_params.p1" placeholder="请输入公司名称" size="large">
          <a-icon slot="prefix" type="bank" :style="{ color: 'rgba(0,0,0,.25)' }"/>
        </a-input>
      </a-form-model-item>
      <a-form-model-item prop="p2">
        <a-input v-model="form_params.p2" placeholder="请输入用户名" size="large">
          <a-icon slot="prefix" type="user" :style="{ color: 'rgba(0,0,0,.25)' }"/>
        </a-input>
      </a-form-model-item>
      <a-form-model-item prop="p3">
        <a-input v-model="form_params.p3" placeholder="请输入手机号" size="large">
          <a-icon slot="prefix" type="phone" :style="{ color: 'rgba(0,0,0,.25)' }"/>
        </a-input>
      </a-form-model-item>
      <a-form-model-item prop="p4">
        <a-form-item :style="{ display: 'inline-block', width: 'calc(60% - 12px)' }">
          <a-input v-model="form_params.p4" size="large" type="text" placeholder="请输入验证码" style="width:100%;" >
            <a-icon slot="prefix" type="qrcode" :style="{ color: 'rgba(0,0,0,.25)' }"/>
          </a-input>
        </a-form-item>
        <span :style="{ display: 'inline-block', width: '24px', textAlign: 'center' , opacity: 0}">-</span>
        <a-form-item :style="{ display: 'inline-block', width: 'calc(40% - 12px)' }">
          <a-button type="primary" size="large" style="width:100%;">发送验证码</a-button>
        </a-form-item>
      </a-form-model-item>
      <a-form-model-item prop="p5" stye="margin-top:-20px;">
        <a-input-password v-model="form_params.p5" size="large" type="password" autocomplete="false" placeholder="请输入密码">
          <a-icon slot="prefix" type="lock" :style="{ color: 'rgba(0,0,0,.25)' }"/>
        </a-input-password>
      </a-form-model-item>
      <a-form-model-item>
        <a-button type="primary" @click="onSubmit" style="width:100%;" size="large">
          账号注册
        </a-button>
      </a-form-model-item>
    </a-form-model>
    <div>
      <a-button @click="$router.push('/passport/Login')" type="link" style="margin-left: -16px;">登陆账号</a-button>
    </div>
  </div>
</template>
<script>
import http from '@/api/http';
import Server from '@/config/server';
import { setAccessToken, setUserInfo } from '@/utils/util';
import {regular, validateOrder} from '@/components/tools/validate.js'
export default {
  data() {
    return {
      form_params: {
        p1: '',
        p2: '',
        p3: '',
        p4: '',
        p5: '',
      },
      rules: {
        p1: [
          { required: true, message: '请输入公司名称', trigger: 'blur' },
        ],
        p2: [
          { required: true, message: '请输入用户名', trigger: 'blur' },
        ],
        p3: [
          { required: true, message: '请输入手机号' },
          { pattern: /^1[3456789]\d{9}$/, message: '请输入正确手机号' },
        ],
        p4: [
          { required: true, message: '请输入验证码', trigger: 'blur' },
        ],
        p5: [
          { required: true, message: '请输入密码', trigger: 'blur' },
        ],
      },
    };
  },
  computed: {},
  created() {
  },
  methods: {
    handleSubmit() {
      let flag = false;
      const that = this;
      this.form.validateFields(['username', 'password'], { force: true }, (err, values) => {
        if (!err) {
          flag = true;
          that.formLogin.username = values.username;
          that.formLogin.password = values.password;
        }
      });

      if (!flag) return;
      http.post(Server.action.login, that.formLogin)
        .then((resData) => {
          if (resData.code === 0) {
            setAccessToken(resData.result.access_token);
            setUserInfo(JSON.stringify(resData.result));
            this.$router.push({
              path: '/dashboard/main',
            });
          }
        });
    },
    onSubmit() {
      this.$refs.ruleForm.validate(valid => {
        if (valid) {
          alert('submit!');
        } else {
          console.log('error submit!!');
          return false;
        }
      });
    },
    handleChange(e) {
      this.checkNick = e.target.checked;
      this.$nextTick(() => {
        this.form.validateFields(['nickname'], { force: true });
      });
    },
  },
};
</script>
<style lang="stylus" scoped>
  .user-layout-login
    label
      font-size: 14px;

    .getCaptcha
      display: block;
      width: 100%;
      height: 40px;

    .forge-password
      font-size: 14px;

    button.login-button
      padding: 0 15px;
      font-size: 16px;
      height: 40px;
      width: 100%;

    .user-login-other
      text-align: left;
      margin-top: 24px;
      line-height: 22px;

      .item-icon
        font-size: 24px;
        color: rgba(0, 0, 0, 0.2);
        margin-left: 16px;
        vertical-align: middle;
        cursor: pointer;
        transition: color 0.3s;

        :hover
          color: #1890ff;

      .register
        float: right;
</style>
